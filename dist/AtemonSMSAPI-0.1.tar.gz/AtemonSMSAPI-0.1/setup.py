from distutils.core import setup

setup(
    name='AtemonSMSAPI',
    version='0.1',
    packages=['SMS',],
    license='MIT Except',
    long_description=open('README.md').read(),
)
