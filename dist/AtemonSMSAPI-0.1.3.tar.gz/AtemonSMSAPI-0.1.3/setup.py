from distutils.core import setup

setup(
    name='AtemonSMSAPI',
    version='0.1.3',
    packages=['SMS', 'SMS/GAG'],
    license='MIT Except',
    long_description="Connect to SMS API with Python",
)
